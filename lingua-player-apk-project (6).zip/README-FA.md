# Lingua Player — ساخت APK با GitHub

## روش (بدون نصب هیچ چیز روی گوشی/کامپیوتر)
1. در GitHub یک ریپازیتوری جدید بسازید (مثلاً `lingua-player`، می‌تواند Private باشد).
2. همه فایل‌های همین پوشه را آپلود کنید (Add file ← Upload files).
   - پوشه‌ها: `www`، `assets`، `scripts` و فایل‌های `package.json`، `capacitor.config.json`، `.gitignore`.
3. **فایل workflow:** اگر پوشه `.github` آپلود نشد (بعضی گوشی‌ها پوشه‌های نقطه‌دار را نشان نمی‌دهند):
   - Add file ← Create new file
   - در کادر نام بنویسید: `.github/workflows/android.yml`
   - محتوای فایل `GITHUB-WORKFLOW-android.yml` را در آن Paste کنید و Commit بزنید.
4. تب **Actions** ← «Build Android APK» ← **Run workflow**.
5. بعد از ۵ تا ۱۰ دقیقه، ساخت تمام می‌شود. وارد همان اجرا شوید و در بخش **Artifacts** فایل `Lingua-Player-APK` را دانلود کنید (zip است؛ داخلش `app-debug.apk`).
6. APK را روی گوشی نصب کنید (اجازه «نصب از منابع ناشناس» را بدهید).

## نکته‌ها
- این APK از نوع debug است و برای استفاده شخصی کافی است. برای انتشار در Google Play / Bazaar باید امضای release اضافه شود (در مرحله بعد انجام می‌دهم).
- اگر ساخت خطا داد، متن خطای تب Actions را برای من بفرستید.
- برای تغییر در برنامه فقط `www/index.html` را عوض کنید و دوباره Run workflow بزنید.
- پخش فایل‌ها: فرمت‌هایی که WebView اندروید پشتیبانی می‌کند (MP4/H.264، WebM، MP3، AAC، OGG، FLAC و ...). برای MKV/AVI و کدک‌های دیگر مرحله بعد پلیر بومی اضافه می‌شود.
