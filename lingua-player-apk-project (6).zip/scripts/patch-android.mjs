// Runs in CI after `cap add android`: small native tweaks for a media player.
import fs from 'fs';
import path from 'path';

const base = 'android/app/src/main';

// 1) Manifest: hardware acceleration + http streams
const mfPath = path.join(base, 'AndroidManifest.xml');
let mf = fs.readFileSync(mfPath, 'utf8');
if (!mf.includes('android:hardwareAccelerated')) mf = mf.replace('<application', '<application android:hardwareAccelerated="true"');
if (!mf.includes('android:usesCleartextTraffic')) mf = mf.replace('<application', '<application android:usesCleartextTraffic="true"');
fs.writeFileSync(mfPath, mf);

// 2) MainActivity: allow media to start without an extra tap
function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(e =>
    e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]);
}
const javaFiles = walk(path.join(base, 'java')).filter(f => f.endsWith('MainActivity.java'));
if (!javaFiles.length) { console.warn('MainActivity.java not found - skipping'); process.exit(0); }
const f = javaFiles[0];
let src = fs.readFileSync(f, 'utf8');
if (!src.includes('setMediaPlaybackRequiresUserGesture')) {
  const re = /public class MainActivity extends BridgeActivity\s*\{\s*\}/;
  if (re.test(src)) {
    src = src.replace(re, `public class MainActivity extends BridgeActivity {
    @Override
    public void onStart() {
        super.onStart();
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
    }
}`);
    fs.writeFileSync(f, src);
    console.log('Patched', f);
  } else console.warn('MainActivity has a different shape - skipping patch');
}
