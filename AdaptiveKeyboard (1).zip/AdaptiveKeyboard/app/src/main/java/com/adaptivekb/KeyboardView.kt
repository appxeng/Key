package com.adaptivekb

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.min

class KeyboardView(ctx: Context, private val store: Store) : View(ctx) {

    class RKey(val def: KeyDef, val r: RectF) {
        val cx get() = r.centerX()
        val cy get() = r.centerY()
        val w get() = r.width()
        val h get() = r.height()
    }

    var onKey: ((KeyDef, Float, Float, Float, Float) -> Unit)? = null
    var onSuggestion: ((String) -> Unit)? = null
    var currentWord = ""
    var suggestions: List<String> = emptyList()
    var layer = 0
        set(v) { field = v; build(); invalidate() }

    private val rkeys = ArrayList<RKey>()
    private val density = resources.displayMetrics.density
    private val stripH get() = if (store.suggest) 40 * density else 6 * density

    private var bgC = 0; private var keyC = 0; private var spC = 0; private var txtC = 0; private var accC = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val handler = Handler(Looper.getMainLooper())

    private var pressed: RKey? = null
    private var sugTap = false

    init { reload() }

    fun reload() {
        when (store.theme) {
            1 -> { bgC = 0xFFE9EBF0.toInt(); keyC = 0xFFFFFFFF.toInt(); spC = 0xFFD3D7E0.toInt(); txtC = 0xFF1B1E26.toInt() }
            2 -> { bgC = 0xFF000000.toInt(); keyC = 0xFF15161A.toInt(); spC = 0xFF0C0D10.toInt(); txtC = 0xFFECEFF4.toInt() }
            else -> { bgC = 0xFF14161C.toInt(); keyC = 0xFF252932.toInt(); spC = 0xFF1D2028.toInt(); txtC = 0xFFECEFF4.toInt() }
        }
        accC = Palette.accents[store.accent.coerceIn(0, Palette.accents.size - 1)]
        requestLayout(); build(); invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        val height = (stripH + store.keyDp * density * 5 + 8 * density).toInt()
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { build() }

    private fun build() {
        rkeys.clear()
        if (width == 0 || height == 0) return
        val rows = Layouts.layers[layer]
        val pad = 4 * density
        val rowH = (height - stripH - 2 * density - pad) / rows.size
        var y = stripH + 2 * density
        for (row in rows) {
            val total = row.sumOf { (it.weight * scaleOfDef(it)).toDouble() }.toFloat()
            val unit = (width - 2 * pad) / total
            var x = pad
            for (k in row) {
                val kw = unit * k.weight * scaleOfDef(k)
                rkeys.add(RKey(k, RectF(x, y, x + kw, y + rowH)))
                x += kw
            }
            y += rowH
        }
    }

    fun cellOf(label: String): RKey? = rkeys.firstOrNull { it.def.learn && it.def.label == label }

    // ---------- تشخیص کلید با مدل گاوسی شخصی ----------
    private fun resolve(x: Float, y: Float): RKey? {
        val cands = ArrayList<Pair<RKey, Float>>()
        for (k in rkeys) {
            val dx = (x - k.cx) / k.w
            val dy = (y - k.cy) / k.h
            if (abs(dx) > 1.4f || abs(dy) > 1.1f) continue
            var mx = 0f; var my = 0f; var sx = 0.45f; var sy = 0.45f
            if (store.adaptive && k.def.learn) {
                val s = store.stat(k.def.label)
                mx = s.mx; my = s.my; sx = s.sx; sy = s.sy
            }
            val ex = (dx - mx) / sx
            val ey = (dy - my) / sy
            cands.add(k to (0.5f * (ex * ex + ey * ey) + ln(sx * sy)))
        }
        if (cands.isEmpty()) return rkeys.minByOrNull { hypot(x - it.cx, y - it.cy) }
        cands.sortBy { it.second }
        if (store.adaptive && cands.size > 1 && currentWord.isNotEmpty() &&
            cands[1].second - cands[0].second < 0.9f
        ) {
            val a = cands[0]; val b = cands[1]
            if (a.first.def.learn && b.first.def.learn) {
                val wa = store.prefixWeight(currentWord + a.first.def.out)
                val wb = store.prefixWeight(currentWord + b.first.def.out)
                val sa = a.second - 0.45f * ln(1f + wa)
                val sb = b.second - 0.45f * ln(1f + wb)
                if (sb < sa) return b.first
            }
        }
        return cands[0].first
    }

    // ---------- لمس ----------
    private val repeat = object : Runnable {
        override fun run() {
            val p = pressed ?: return
            if (p.def.kind == Kind.BACKSPACE) {
                onKey?.invoke(p.def, 0f, 0f, 0f, 0f)
                handler.postDelayed(this, 45)
            }
        }
    }

    private fun buzz() {
        if (store.haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (store.suggest && e.y < stripH) { sugTap = true; return true }
                sugTap = false
                pressed = resolve(e.x, e.y)
                buzz()
                val p = pressed
                if (p != null && p.def.kind == Kind.BACKSPACE) {
                    onKey?.invoke(p.def, 0f, 0f, 0f, 0f)
                    handler.postDelayed(repeat, 380)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val p = pressed
                if (!sugTap && p != null && p.def.kind != Kind.BACKSPACE) {
                    val k = resolve(e.x, e.y)
                    if (k !== p) { pressed = k; invalidate() }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(repeat)
                if (sugTap) {
                    sugTap = false
                    val idx = 2 - (e.x / (width / 3f)).toInt()
                    suggestions.getOrNull(idx)?.let { onSuggestion?.invoke(it) }
                } else if (pressed != null) {
                    val k = resolve(e.x, e.y) ?: pressed!!
                    if (k.def.kind != Kind.BACKSPACE) {
                        onKey?.invoke(k.def, (e.x - k.cx) / k.w, (e.y - k.cy) / k.h, e.x, e.y)
                    }
                }
                pressed = null
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeat); pressed = null; sugTap = false; invalidate()
            }
        }
        return true
    }

    // ---------- رسم ----------
    private fun scaleOfDef(d: KeyDef): Float =
        if (store.grow && d.learn) 1f + 0.5f * min(1f, store.errorRate(d.label) * 5f) else 1f

    private fun scaleOf(k: RKey): Float = scaleOfDef(k.def)

    /** بعد از هر یادگیری، چیدمان دوباره محاسبه می‌شود */
    fun rebuild() { build(); invalidate() }

    override fun onDraw(c: Canvas) {
        c.drawColor(bgC)
        if (store.suggest) drawStrip(c)
        for (k in rkeys.sortedBy { scaleOf(it) }) drawKey(c, k)
        drawBubble(c)
    }

    private fun drawStrip(c: Canvas) {
        text.color = txtC
        text.textSize = 16 * density
        val slot = width / 3f
        for (i in 0..2) {
            val s = suggestions.getOrNull(i) ?: continue
            c.drawText(s, width - (i + 0.5f) * slot, stripH / 2 + 6 * density, text)
            if (i < 2) {
                paint.color = Color.argb(40, 128, 128, 128)
                c.drawRect(width - (i + 1) * slot - 0.5f, 8 * density, width - (i + 1) * slot + 0.5f, stripH - 8 * density, paint)
            }
        }
    }

    private fun drawKey(c: Canvas, k: RKey) {
        val gap = 2.5f * density
        val sc = scaleOf(k)
        val r = RectF(k.r)
        r.inset(gap, gap)
        if (sc > 1f) r.inset(0f, -k.h * (sc - 1f) / 8f)
        val isP = pressed === k
        val special = k.def.kind != Kind.CHAR || !k.def.learn && k.def.label.length > 1
        paint.color = when {
            isP -> accC
            k.def.kind == Kind.ENTER -> accC
            special -> spC
            else -> keyC
        }
        val rad = 9 * density
        c.drawRoundRect(r, rad, rad, paint)

        if (store.heat && k.def.learn && !isP) {
            val er = min(1f, store.errorRate(k.def.label) * 3f)
            paint.color = Color.argb((er * 130).toInt(), Color.red(accC), Color.green(accC), Color.blue(accC))
            c.drawRoundRect(r, rad, rad, paint)
            val s = store.stat(k.def.label)
            paint.color = Color.argb(200, Color.red(accC), Color.green(accC), Color.blue(accC))
            c.drawCircle(k.cx + s.mx * k.w, k.cy + s.my * k.h, 2.5f * density, paint)
        }

        val long = k.def.label.length > 1
        text.textSize = k.h * (if (long) 0.26f else 0.38f)
        text.color = if (isP || k.def.kind == Kind.ENTER) Color.WHITE else txtC
        val dy = -(text.ascent() + text.descent()) / 2f
        c.drawText(k.def.label, r.centerX(), r.centerY() + dy, text)
    }

    private fun drawBubble(c: Canvas) {
        val p = pressed ?: return
        if (!store.preview || p.def.kind != Kind.CHAR) return
        val bw = p.w * 1.5f
        val bh = p.h * 1.15f
        val left = (p.cx - bw / 2).coerceIn(2 * density, width - bw - 2 * density)
        val top = (p.r.top - bh - 4 * density).coerceAtLeast(0f)
        val r = RectF(left, top, left + bw, top + bh)
        paint.color = accC
        c.drawRoundRect(r, 12 * density, 12 * density, paint)
        text.color = Color.WHITE
        text.textSize = p.h * 0.6f
        val dy = -(text.ascent() + text.descent()) / 2f
        c.drawText(p.def.label, r.centerX(), r.centerY() + dy, text)
    }
}
