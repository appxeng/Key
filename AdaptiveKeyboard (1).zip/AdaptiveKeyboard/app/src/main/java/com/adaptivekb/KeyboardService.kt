package com.adaptivekb

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import kotlin.math.abs

class KeyboardService : InputMethodService() {

    private val store by lazy { Store.get(this) }
    private lateinit var view: KeyboardView

    private class Stroke(val label: String, val x: Float, val y: Float)

    private val history = ArrayList<Stroke>()   // ضربه‌های ثبت‌شده
    private val deleted = ArrayList<Stroke>()   // پاک‌شده‌ها (به ترتیب اصلی تایپ)
    private val retyped = ArrayList<Stroke>()   // بازنویسی بعد از پاک کردن
    private var lastAct = 0L

    override fun onCreateInputView(): View {
        view = KeyboardView(this, store)
        view.onKey = { d, nx, ny, x, y -> handleKey(d, nx, ny, x, y) }
        view.onSuggestion = { pickSuggestion(it) }
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        history.clear(); deleted.clear(); retyped.clear()
        view.reload()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        view.layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) 2 else 0
        refresh()
    }

    override fun onFinishInput() { super.onFinishInput(); store.save() }
    override fun onDestroy() { store.save(); super.onDestroy() }

    // ---------- کلیدها ----------
    private fun handleKey(k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val ic = currentInputConnection ?: return
        when (k.kind) {
            Kind.BACKSPACE -> {
                val sel = ic.getSelectedText(0)
                if (!sel.isNullOrEmpty()) {
                    ic.commitText("", 1); history.clear(); deleted.clear(); retyped.clear()
                } else {
                    ic.deleteSurroundingText(1, 0)
                    if (retyped.isNotEmpty()) { deleted.clear(); retyped.clear() }
                    if (history.isNotEmpty()) {
                        deleted.add(0, history.removeAt(history.lastIndex))
                    }
                    lastAct = SystemClock.uptimeMillis()
                }
            }
            Kind.SPACE -> { endWord(ic); ic.commitText(if (k.label == "space") " " else " ", 1); history.clear() }
            Kind.ENTER -> {
                endWord(ic)
                val ei = currentInputEditorInfo
                val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (ei == null || noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.commitText("\n", 1)
                else ic.performEditorAction(action)
                history.clear()
            }
            Kind.LAYER -> view.layer = k.target
            Kind.CHAR -> typeChar(ic, k, nx, ny, x, y)
        }
        refresh()
    }

    private fun typeChar(ic: android.view.inputmethod.InputConnection, k: KeyDef, nx: Float, ny: Float, x: Float, y: Float) {
        val o = k.out
        if (!(o[0].isLetter() || o == "\u200c")) endWord(ic)
        ic.commitText(o, 1)
        if (!k.learn) return

        val now = SystemClock.uptimeMillis()
        store.strokeCommitted(k.label)
        val s = Stroke(k.label, x, y)

        if (deleted.isNotEmpty() && now - lastAct < 4000) {
            retyped.add(s)
            lastAct = now
            if (retyped.size >= deleted.size) { evaluate(); deleted.clear(); retyped.clear() }
        } else { deleted.clear(); retyped.clear() }

        history.add(s)
        if (history.size > 60) history.removeAt(0)
        if (store.adaptive) store.learnSample(k.label, nx, ny, 0.01f)
    }

    /** «حذف و بازنویسی» را مقایسه می‌کند و از اشتباه‌ها یاد می‌گیرد */
    private fun evaluate() {
        val n = deleted.size
        if (n > 4) return
        val pairs = ArrayList<Pair<Stroke, Stroke>>()
        for (i in 0 until n) if (deleted[i].label != retyped[i].label) pairs.add(deleted[i] to retyped[i])
        if (pairs.isEmpty() || pairs.size > (n + 1) / 2) return
        for ((old, new) in pairs) {
            val want = view.cellOf(new.label) ?: continue
            val hit = view.cellOf(old.label) ?: continue
            // فقط اگر همسایه‌ی فیزیکی باشند، اشتباه لمسی حساب می‌شود
            if (abs(want.cx - hit.cx) / want.w > 1.7f || abs(want.cy - hit.cy) / want.h > 1.2f) continue
            val nx = (old.x - want.cx) / want.w
            val ny = (old.y - want.cy) / want.h
            if (abs(nx) > 1.3f || abs(ny) > 1.1f) continue
            if (store.adaptive) store.learnSample(new.label, nx, ny, 0.12f)
            store.recordError(new.label, old.label)
        }
        view.rebuild()
    }

    // ---------- کلمه و پیشنهاد ----------
    private fun trailingWord(ic: android.view.inputmethod.InputConnection): String {
        val t = ic.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = t.length
        while (i > 0 && (t[i - 1].isLetter() || t[i - 1] == '\u200c')) i--
        return t.substring(i)
    }

    private fun endWord(ic: android.view.inputmethod.InputConnection) { store.learnWord(trailingWord(ic)) }

    private fun pickSuggestion(w: String) {
        val ic = currentInputConnection ?: return
        val cur = trailingWord(ic)
        ic.deleteSurroundingText(cur.length, 0)
        ic.commitText("$w ", 1)
        store.learnWord(w)
        history.clear(); deleted.clear(); retyped.clear()
        refresh()
    }

    private fun refresh() {
        val ic = currentInputConnection
        val cur = if (ic != null) trailingWord(ic) else ""
        view.currentWord = cur
        view.suggestions = if (store.suggest && cur.isNotEmpty()) store.suggestions(cur) else emptyList()
        view.invalidate()
    }
}
