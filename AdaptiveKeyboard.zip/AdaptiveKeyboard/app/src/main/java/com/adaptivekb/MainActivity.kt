package com.adaptivekb

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var st: Store
    private val BG = 0xFF0F1117.toInt()
    private val CARD = 0xFF1A1D26.toInt()
    private val MUTED = 0xFF8D93A5.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val accent get() = Palette.accents[st.accent.coerceIn(0, Palette.accents.size - 1)]
    private var sentence = 0
    private var scrollY = 0
    private lateinit var scroll: ScrollView

    private val sentences = listOf(
        "مکانیک ماشین را درست کرد",
        "راهبه در صومعه زندگی می‌کند",
        "امروز هوا خیلی خوب است",
        "گربه‌ی کوچک روی دیوار نشسته بود",
        "کتاب خوب بهترین همراه سفر است",
        "تهران شهر شلوغ و پرجنب‌وجوش است"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store.get(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
    }

    override fun onResume() { super.onResume(); build() }
    override fun onPause() { super.onPause(); st.save() }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun String.fa() = map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

    private fun round(color: Int, r: Float = 16f) =
        GradientDrawable().apply { setColor(color); cornerRadius = r * resources.displayMetrics.density }

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.START
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(CARD, 20f)
            setPadding(px(18), px(16), px(18), px(18))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(14) }
        }
        c.addView(tv(title, 17f, Color.WHITE, true))
        if (sub != null) c.addView(tv(sub, 13f, MUTED).apply { setPadding(0, px(4), 0, px(6)) })
        return c
    }

    private fun pill(t: String, filled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; textSize = 15f
        background = round(if (filled) accent else 0xFF2A2E3A.toInt(), 14f)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, px(48)).apply { topMargin = px(8) }
    }

    private fun switchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(8), 0, px(8))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        col.addView(tv(title, 15f))
        col.addView(tv(sub, 12f, MUTED))
        val sw = Switch(this).apply { isChecked = on; setOnCheckedChangeListener { _, v -> change(v) } }
        row.addView(col); row.addView(sw)
        return row
    }

    private fun build() {
        if (::scroll.isInitialized) scrollY = scroll.scrollY
        scroll = ScrollView(this).apply { setBackgroundColor(BG); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(px(16), px(28), px(16), px(40))
        }
        scroll.addView(col)

        col.addView(tv("کیبورد هوشمند من", 26f, Color.WHITE, true))
        col.addView(tv("هر چه بیشتر تایپ کنی، دقیق‌تر و شخصی‌تر می‌شود", 14f, MUTED).apply { setPadding(0, px(4), 0, 0) })

        // ----- راه‌اندازی -----
        val setup = card("راه‌اندازی", "اول کیبورد را فعال کن، بعد آن را انتخاب کن")
        setup.addView(pill("۱. فعال‌سازی کیبورد") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        setup.addView(pill("۲. انتخاب کیبورد", false) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(setup)

        // ----- تمرین -----
        val train = card("تمرین سریع", "جمله را بنویس تا کیبورد زودتر با انگشت‌هایت آشنا شود")
        val target = tv(sentences[sentence], 18f, accent, true).apply { setPadding(0, px(6), 0, px(10)) }
        val field = EditText(this).apply {
            hint = "اینجا تایپ کن…"; setHintTextColor(MUTED); setTextColor(Color.WHITE)
            background = round(0xFF11131A.toInt(), 14f); setPadding(px(14), px(12), px(14), px(12))
            gravity = Gravity.START
        }
        train.addView(target); train.addView(field)
        train.addView(pill("جمله‌ی بعدی", false) {
            sentence = (sentence + 1) % sentences.size; target.text = sentences[sentence]; field.setText("")
        })
        col.addView(train)

        // ----- آمار -----
        val days = st.last7()
        val stats = card("پیشرفت دقت تایپ", "درصد ضربه‌هایی که نیاز به اصلاح نداشتند (۷ روز اخیر)")
        stats.addView(BarsView(this, days, accent).apply { layoutParams = LinearLayout.LayoutParams(MATCH, px(140)) })
        val totalErr = st.keys.values.sumOf { it.errors }
        stats.addView(tv("اصلاح‌های یادگرفته‌شده: ${totalErr.toString().fa()}   |   کلمه‌های حفظ‌شده: ${st.words.size.toString().fa()}", 13f, MUTED)
            .apply { setPadding(0, px(8), 0, px(6)) })
        val top = st.confusion.entries.sortedByDescending { it.value }.take(5)
        if (top.isEmpty()) {
            stats.addView(tv("هنوز اشتباهی ثبت نشده. تایپ کن و اشتباه‌هایت را پاک کن و درست بنویس!", 13f, MUTED))
        } else {
            stats.addView(tv("بیشترین اشتباه‌ها", 14f, Color.WHITE, true).apply { setPadding(0, px(6), 0, px(4)) })
            for (e in top) {
                val p = e.key.split(">")
                stats.addView(tv("می‌خواستی «${p[0]}» بزنی، «${p[1]}» خورد  ←  ${e.value.toString().fa()} بار", 13f, 0xFFC9CEDB.toInt()))
            }
        }
        col.addView(stats)

        // ----- شخصی‌سازی -----
        val look = card("ظاهر و حس کیبورد")
        look.addView(tv("رنگ اصلی", 13f, MUTED).apply { setPadding(0, px(6), 0, px(6)) })
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Palette.accents.forEachIndexed { i, c ->
            val d = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c)
                    if (i == st.accent) setStroke(px(3), Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(px(38), px(38)).apply { marginEnd = px(10) }
                setOnClickListener { st.accent = i; build() }
            }
            dots.addView(d)
        }
        look.addView(dots)
        look.addView(tv("تم", 13f, MUTED).apply { setPadding(0, px(14), 0, px(2)) })
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("تیره", "روشن", "آمولد").forEachIndexed { i, n ->
            val b = Button(this).apply {
                text = n; isAllCaps = false; setTextColor(Color.WHITE)
                background = round(if (st.theme == i) accent else 0xFF2A2E3A.toInt(), 12f)
                layoutParams = LinearLayout.LayoutParams(0, px(42), 1f).apply { marginEnd = px(8) }
                setOnClickListener { st.theme = i; build() }
            }
            themes.addView(b)
        }
        look.addView(themes)
        look.addView(tv("ارتفاع کلیدها: ${st.keyDp.toString().fa()}", 13f, MUTED).apply { setPadding(0, px(14), 0, 0) })
        look.addView(SeekBar(this).apply {
            max = 24; progress = st.keyDp - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { st.keyDp = 40 + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { build() }
            })
        })
        look.addView(switchRow("نمایش پیش‌نمایش حرف", "حباب بالای کلید", st.preview) { st.preview = it })
        look.addView(switchRow("لرزش هنگام تایپ", "بازخورد لمسی", st.haptic) { st.haptic = it })
        look.addView(switchRow("نوار پیشنهاد کلمه", "از کلمه‌هایی که خودت می‌نویسی", st.suggest) { st.suggest = it })
        col.addView(look)

        val ai = card("یادگیری", "همه‌ی داده‌ها فقط روی همین گوشی می‌مانند")
        ai.addView(switchRow("جابجایی نامرئی ناحیه‌ی لمس", "ظاهر ثابت، دقت بیشتر (پیشنهادی)", st.adaptive) { st.adaptive = it })
        ai.addView(switchRow("بزرگ‌شدن ظاهری کلیدهای پراشتباه", "تا ۱۸٪ بزرگ‌تر", st.grow) { st.grow = it })
        ai.addView(switchRow("نمای حرارتی", "نشان‌دادن کلیدهای پراشتباه و مرکز لمس تو", st.heat) { st.heat = it })
        ai.addView(pill("پاک‌کردن همه‌ی یادگیری", false) { st.resetLearning(); build() })
        col.addView(ai)

        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, scrollY) }
    }

    /** نمودار میله‌ای ساده‌ی دقت */
    class BarsView(ctx: Context, private val data: List<Triple<Int, Int, Int>>, private val color: Int) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private fun fa(s: String) = s.map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")
        override fun onDraw(c: Canvas) {
            val d = resources.displayMetrics.density
            val n = data.size
            val slot = width / n.toFloat()
            val chartH = height - 34 * d
            p.textAlign = Paint.Align.CENTER
            for (i in 0 until n) {
                val (s, e, day) = data[n - 1 - i]       // راست به چپ: قدیمی‌ترین سمت راست
                val cx = slot * (i + 0.5f)
                val bw = slot * 0.46f
                p.color = 0xFF262A36.toInt()
                c.drawRoundRect(RectF(cx - bw / 2, 16 * d, cx + bw / 2, 16 * d + chartH), 8 * d, 8 * d, p)
                if (s > 0) {
                    val acc = (1f - e.toFloat() / s).coerceIn(0f, 1f)
                    val frac = ((acc - 0.5f) / 0.5f).coerceIn(0.04f, 1f)
                    p.color = color
                    c.drawRoundRect(RectF(cx - bw / 2, 16 * d + chartH * (1 - frac), cx + bw / 2, 16 * d + chartH), 8 * d, 8 * d, p)
                    p.color = Color.WHITE; p.textSize = 10 * d
                    c.drawText(fa("${(acc * 100).toInt()}"), cx, 12 * d, p)
                }
                p.color = 0xFF8D93A5.toInt(); p.textSize = 11 * d
                c.drawText(fa(day.toString()), cx, height - 6 * d, p)
            }
        }
    }
}
